package com.kafkaDemo.kafka_springboot_demo.controller;

import com.kafkaDemo.kafka_springboot_demo.kafka.JsonKafkaProducer;
import com.kafkaDemo.kafka_springboot_demo.payload.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/kafka/")
public class JsonMessageController {
    private JsonKafkaProducer jsonKafkaProducer;

    @Autowired
    public JsonMessageController(JsonKafkaProducer jsonKafkaProducer) {
        this.jsonKafkaProducer = jsonKafkaProducer;
    }

    @PostMapping("publish")
    public ResponseEntity<String> publish(@RequestBody User user) {
        jsonKafkaProducer.sendMessage(user);
        return ResponseEntity.ok("JSON Message sent to Kafka Topic");
    }
}
