package com.kafkaDemo.kafka_springboot_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaSpringbootDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
